# NYC Food Insecurity Vulnerability Scorer

## What This Does
Scores all 59 NYC Community Districts by their vulnerability to food insecurity
and federal SNAP cuts. Output is a JSON file ready to power a Leaflet.js map.

## Vulnerability Score Formula
| Indicator | Weight | Source |
|---|---|---|
| SNAP household enrollment rate | 35% | NYC HRA via CCC, 2024 |
| Child poverty rate (under 5) | 20% | NYC EH Portal, 2017-21 |
| Rent-burdened households | 20% | NYC EH Portal, 2017-21 |
| Unemployment rate | 15% | NYC EH Portal, 2017-21 |
| Non-citizen population | 10% | ACS via CCC, 2023 |

Score range: 0–100. Higher = more vulnerable to food insecurity + federal cuts.

## Risk Tiers
- 🔴 Critical (70–100): Immediate intervention needed
- 🟠 High (50–69): High risk, monitor closely
- 🟡 Moderate (30–49): Moderate risk
- 🟢 Lower (0–29): Lower relative risk

## Setup on Replit

### 1. File Structure
```
your-replit/
├── process_data.py
├── README.md
├── vulnerability_scores.json  ← generated after running script
└── data/
    ├── SNAP (Food Stamps).csv
    ├── Citizenship.csv
    ├── NYC_EH_Rent-burdened_households.csv
    ├── NYC_EH_Child_poverty_under_age_5.csv
    └── NYC_EH_Unemployment.csv
```

### 2. Upload Your Data Files
Upload into the `/data` folder with these exact names:
- `SNAP (Food Stamps).csv` — from CCC data download
- `Citizenship.csv` — from CCC data download
- `NYC_EH_Rent-burdened_households.csv` — from NYC EH Portal
- `NYC_EH_Child_poverty_under_age_5.csv` — from NYC EH Portal
- `NYC_EH_Unemployment.csv` — from NYC EH Portal

### 3. Run
```bash
python process_data.py
```

### 4. Output
`vulnerability_scores.json` — plug this into your Leaflet.js map.

## Output JSON Structure
```json
{
  "metadata": {
    "description": "...",
    "scoring_weights": {...},
    "data_sources": {...},
    "total_districts": 59,
    "critical_count": 8,
    "high_count": 10
  },
  "districts": [
    {
      "fips": "205",
      "cd_name": "University Heights",
      "borough": "Bronx",
      "vulnerability_score": 91.2,
      "risk_tier": "Critical",
      "color": "#d32f2f",
      "indicators": {
        "snap_household_pct": 73.1,
        "child_poverty_pct": 49.3,
        "rent_burden_pct": 61.2,
        "unemployment_pct": 14.6,
        "noncitizen_pct": 27.6
      }
    }
  ]
}
```

## Next Steps (Week 18 Build)
1. Load `vulnerability_scores.json` into your Leaflet map
2. Add NYC Community District GeoJSON (from NYC Open Data)
3. Color choropleth by `color` field (already set per risk tier)
4. Add pantry markers from NYC Open Data CFC dataset
5. Build sidebar showing top 10 highest-risk districts

## Data Sources
- CCC KTO Data: https://data.cccnewyork.org
- NYC EH Portal: https://a816-dohbesp.nyc.gov/IndicatorPublic/
- NYC Open Data SNAP: https://data.cityofnewyork.us/Social-Services/Borough-Community-District-Report-SNAP-Population/jye8-w4d7
- NYC Community District GeoJSON: https://data.cityofnewyork.us/City-Government/Community-Districts/jp9i-3b7y
